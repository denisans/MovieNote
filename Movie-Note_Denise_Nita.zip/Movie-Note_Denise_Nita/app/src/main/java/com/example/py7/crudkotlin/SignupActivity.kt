package <package_name>

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class SignupActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)

        val btnSignup: Button = findViewById(R.id.btnSignup)
        val btnGoToLogin: Button = findViewById(R.id.btnGoToLogin)

        btnSignup.setOnClickListener {
            // Logika untuk signup
            // Anda bisa menambahkan pengecekan email, password, dan konfirmasi password di sini
        }

        btnGoToLogin.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }
    }
}
